import { useState } from 'react';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import '../styles/AuthPush.css';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';

function AuthMain({ setStage, setShowAuthPush }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async () => {
        const auth = getAuth();
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;
            Cookies.set('userId', user.uid); // Сохраняем ID пользователя в куки
            setShowAuthPush(false);
            navigate(0); // Перезагрузка страницы
        } catch (error) {
            setError('Ошибка при входе в систему. Проверьте логин и пароль.');
        }
    };

    return (
        <>
            <p className="auth-push-title">Вход</p>
            <div className="auth-push-input">
                <input
                    type="email"
                    placeholder="Логин"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
            </div>
            <div className="auth-push-input">
                <input
                    type="password"
                    placeholder="Пароль"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
            </div>
            {error && <p className="auth-push-error">{error}</p>}
            <div className="auth-push-btn-auth" onClick={handleLogin}>
                <p className="auth-push-btn-auth-text">Войти</p>
            </div>
            <p className="auth-push-remember-btn">Восстановить пароль</p>
        </>
    );
}

export default AuthMain;