import '../styles/NewsPage.css';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import StandartCard from './StandartCard';
import { ref, get } from 'firebase/database';
import { getAuth } from 'firebase/auth';
import { database } from '../firebaseConfig';
import Cookies from 'js-cookie';
import Loader from './Loader';

const NewsPage = () => {
    const [currentTab, setCurrentTab] = useState('All');
    const [news, setNews] = useState([]);
    const [events, setEvents] = useState([]);
    const [devices, setDevices] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 6;
    const [permissions, setPermissions] = useState({ newspage: false });
    const [userName, setUserName] = useState('Гость');
    const [showModal, setShowModal] = useState(false);
    const [modalMessage, setModalMessage] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const auth = getAuth();
                const currentUser = auth.currentUser || Cookies.get('userId');
                let roleId = 2; // Default role ID for "Гость"

                if (currentUser) {
                    const userRef = ref(database, `Users/${currentUser}`);
                    const userSnapshot = await get(userRef);
                    if (userSnapshot.exists()) {
                        const userData = userSnapshot.val();
                        setUserName(userData.Name);
                        roleId = userData.role;
                    }
                }

                const roleRef = ref(database, `Roles/${roleId}`);
                const roleSnapshot = await get(roleRef);
                if (roleSnapshot.exists()) {
                    const roleData = roleSnapshot.val();
                    setPermissions(roleData.permissions);
                    console.log('Role Data:', roleData);

                    if (!roleData.permissions.newspage) {
                        const message = roleId === 2
                            ? 'У вас недостаточно прав для просмотра этой страницы. Пожалуйста, авторизуйтесь в системе.'
                            : 'У вас недостаточно прав для просмотра этой страницы. Пожалуйста, обратитесь к администратору.';
                        setModalMessage(message);
                        setShowModal(true);
                        setLoading(false);
                        return;
                    }

                    const [newsSnapshot, eventsSnapshot, devicesSnapshot] = await Promise.all([
                        get(ref(database, 'News')),
                        get(ref(database, 'Events')),
                        get(ref(database, 'Devices'))
                    ]);

                    if (newsSnapshot.exists()) {
                        const newsData = [];
                        newsSnapshot.forEach((childSnapshot) => {
                            const item = childSnapshot.val();
                            if (item.status === 'Опубликовано') {
                                newsData.push({
                                    ...item,
                                    id: childSnapshot.key
                                });
                            }
                        });
                        setNews(newsData);
                    }

                    if (eventsSnapshot.exists()) {
                        const eventsData = [];
                        eventsSnapshot.forEach((childSnapshot) => {
                            const item = childSnapshot.val();
                            if (item.status === 'Опубликовано') {
                                eventsData.push({
                                    ...item,
                                    id: childSnapshot.key
                                });
                            }
                        });
                        setEvents(eventsData);
                    }

                    if (devicesSnapshot.exists()) {
                        const devicesData = [];
                        devicesSnapshot.forEach((childSnapshot) => {
                            devicesData.push({
                                id: childSnapshot.key,
                                ...childSnapshot.val()
                            });
                        });
                        setDevices(devicesData);
                    }
                } else {
                    throw new Error('Роль не найдена');
                }
            } catch (error) {
                console.error('Ошибка при загрузке данных:', error);
                setError('Не удалось загрузить данные');
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const newsTypeList = { 'Ads': 'Объявления', 'Devices': 'Устройства и ПО', 'Activity': 'Мероприятия' };

    const onTabClickHandler = (e) => {
        const selectedTab = e.target.dataset.tab;
        setCurrentTab(selectedTab);
        setCurrentPage(1);
    };

    const renderNews = (type) => {
        const sortedNews = [...news].sort((a, b) => {
            if (!a.postData) return 1;
            if (!b.postData) return -1;
            return new Date(b.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + b.postData.split(', ')[1]) - 
                   new Date(a.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + a.postData.split(', ')[1]);
        });

        const filteredNews = type 
            ? sortedNews.filter(news => news.elementType === type && news.status === 'Опубликовано')
            : sortedNews.filter(news => news.status === 'Опубликовано');

        const indexOfLastItem = currentPage * itemsPerPage;
        const indexOfFirstItem = indexOfLastItem - itemsPerPage;
        const currentItems = filteredNews.slice(indexOfFirstItem, indexOfLastItem);

        return currentItems.map(e => (
            <Link to={`/news/${e.id}`} key={e.id}>
                <StandartCard 
                    title={e.title} 
                    text={e.text} 
                    publicDate={e.postData} 
                    images={e.images} 
                />
            </Link>
        ));
    };

    const renderDevices = () => {
        const indexOfLastItem = currentPage * itemsPerPage;
        const indexOfFirstItem = indexOfLastItem - itemsPerPage;
        const currentItems = devices.slice(indexOfFirstItem, indexOfLastItem);

        return currentItems.map(e => (
            <Link to={`/devices/${e.id}`} key={e.id}>
                <StandartCard 
                    title={e.id} 
                    text={e.description} 
                    status={e.type_device} 
                    publicDate={e.postData} 
                    images={e.images} 
                />
            </Link>
        ));
    };

    const renderEvents = () => {
        const sortedEvents = [...events].sort((a, b) => {
            if (!a.postData) return 1;
            if (!b.postData) return -1;
            return new Date(b.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + b.postData.split(', ')[1]) - 
                   new Date(a.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + a.postData.split(', ')[1]);
        });

        const filteredEvents = sortedEvents.filter(event => event.status === 'Опубликовано');
        const indexOfLastItem = currentPage * itemsPerPage;
        const indexOfFirstItem = indexOfLastItem - itemsPerPage;
        const currentItems = filteredEvents.slice(indexOfFirstItem, indexOfLastItem);

        return currentItems.map(e => (
            <Link to={`/events/${e.id}`} key={e.id}>
                <StandartCard 
                    title={e.title} 
                    text={e.text} 
                    publicDate={e.postData} 
                    images={e.images} 
                />
            </Link>
        ));
    };

    const renderAll = () => {
        const sortedNews = [...news]
            .filter(news => news.status === 'Опубликовано')
            .sort((a, b) => {
                if (!a.postData) return 1;
                if (!b.postData) return -1;
                return new Date(b.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + b.postData.split(', ')[1]) - 
                       new Date(a.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + a.postData.split(', ')[1]);
            });

        const sortedEvents = [...events]
            .filter(event => event.status === 'Опубликовано')
            .sort((a, b) => {
                if (!a.postData) return 1;
                if (!b.postData) return -1;
                return new Date(b.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + b.postData.split(', ')[1]) - 
                       new Date(a.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + a.postData.split(', ')[1]);
            });

        const combined = [...sortedNews, ...sortedEvents].sort((a, b) => {
            if (!a.postData || !b.postData) return 0;
            return new Date(b.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + b.postData.split(', ')[1]) - 
                   new Date(a.postData.split(', ')[0].split('.').reverse().join('-') + 'T' + a.postData.split(', ')[1]);
        });

        const indexOfLastItem = currentPage * itemsPerPage;
        const indexOfFirstItem = indexOfLastItem - itemsPerPage;
        const currentItems = combined.slice(indexOfFirstItem, indexOfLastItem);

        return currentItems.map(e => (
            <Link to={`/${e.elementType === 'Мероприятия' ? 'events' : 'news'}/${e.id}`} key={e.id}>
                <StandartCard 
                    title={e.title} 
                    text={e.text} 
                    publicDate={e.postData} 
                    images={e.images} 
                />
            </Link>
        ));
    };

    const getFilteredItems = () => {
        switch (currentTab) {
            case 'All':
                return [...news, ...events];
            case 'Devices':
                return devices;
            case 'Activity':
                return events;
            default:
                return news.filter(news => news.elementType === newsTypeList[currentTab]);
        }
    };

    const filteredItems = getFilteredItems();
    const pageCount = Math.ceil(filteredItems.length / itemsPerPage);
    const pageNumbers = Array.from({ length: pageCount }, (_, i) => i + 1);

    const renderPageNumbers = pageNumbers.map(number => (
        <li key={number} className={`page-item ${currentPage === number ? 'active' : ''}`}>
            <a onClick={() => setCurrentPage(number)} className="page-link">
                {number}
            </a>
        </li>
    ));

    if (loading) return <Loader />;
    if (error) return <p>{error}</p>;

    return (
        <div className="page-content news-page">
            {showModal && (
                <div className="modal">
                    <div className="modal-content">
                        <p>{modalMessage}</p>
                        <button onClick={() => setShowModal(false)}>Закрыть</button>
                    </div>
                </div>
            )}
            <div className="bid-page-head noselect">
                <p 
                    className={`bid-page-head-tab ${currentTab === 'All' ? 'bid-page-head-tab-selected' : ''}`} 
                    data-tab="All" 
                    onClick={onTabClickHandler}
                >
                    Все
                </p>
                <p 
                    className={`bid-page-head-tab ${currentTab === 'Ads' ? 'bid-page-head-tab-selected' : ''}`} 
                    data-tab="Ads" 
                    onClick={onTabClickHandler}
                >
                    Объявления
                </p>
                <p 
                    className={`bid-page-head-tab ${currentTab === 'Devices' ? 'bid-page-head-tab-selected' : ''}`} 
                    data-tab="Devices" 
                    onClick={onTabClickHandler}
                >
                    Устройства и ПО
                </p>
                <p 
                    className={`bid-page-head-tab ${currentTab === 'Activity' ? 'bid-page-head-tab-selected' : ''}`} 
                    data-tab="Activity" 
                    onClick={onTabClickHandler}
                >
                    Мероприятия
                </p>
            </div>
            <div className="news-page-content">
                {currentTab === 'Devices' && renderDevices()}
                {currentTab !== 'All' && currentTab !== 'Activity' && currentTab !== 'Devices' && renderNews(newsTypeList[currentTab])}
                {currentTab === 'All' && renderAll()}
                {currentTab === 'Activity' && renderEvents()}
            </div>
            {filteredItems.length > itemsPerPage && (
                <ul className="pagination">
                    {renderPageNumbers}
                </ul>
            )}
        </div>
    );
};

export default NewsPage;