function InputComponent({placeholder}) {
    return ( 
        <div className="custom-input">
            
        </div>
     );
}

export default InputComponent;