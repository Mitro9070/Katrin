function BackgroundClose({closeWindow}) {
    return ( 
        <div className="bg-close" onClick={() => closeWindow()}></div>
     );
}

export default BackgroundClose;