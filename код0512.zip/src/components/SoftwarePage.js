import React from 'react';
import '../styles/SoftwarePage.css'; // Создайте этот файл стилей

const SoftwarePage = () => {
  return (
    <div className="page-content software-page">
      <h1>Программное обеспечение</h1>
      <p>Здесь будет размещена информация о программном обеспечении.</p>
    </div>
  );
};

export default SoftwarePage;